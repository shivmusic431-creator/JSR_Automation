// Firebase Configuration (Replace with your config)
const firebaseConfig = {
  apiKey: "AIzaSyCe8gQEm6RF-5crphw6AKWy728_-sgyL3Y",
  authDomain: "sr777club.firebaseapp.com",
  databaseURL: "https://sr777club-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "sr777club",
  storageBucket: "sr777club.firebasestorage.app",
  messagingSenderId: "718154564331",
  appId: "1:718154564331:web:c6828363411ac50861f4ae"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
const db = firebase.firestore();

// Set auth persistence to LOCAL for remember me (24 hours)
auth.setPersistence(firebase.auth.Auth.Persistence.LOCAL)
    .catch((error) => {
        console.error("Error setting auth persistence:", error);
    });

// DOM Elements
const authContainer = document.getElementById('auth-container');
const appContainer = document.getElementById('app-container');
const loginForm = document.getElementById('login-form');
const registerForm = document.getElementById('register-form');
const forgotPasswordForm = document.getElementById('forgot-password-form');
const showRegister = document.getElementById('show-register');
const showLogin = document.getElementById('show-login');
const showLoginFromForgot = document.getElementById('show-login-from-forgot');
const forgotPasswordLink = document.getElementById('forgot-password');
const loginEmail = document.getElementById('login-email');
const loginPassword = document.getElementById('login-password');
const rememberMe = document.getElementById('remember-me');
const resetEmail = document.getElementById('reset-email');
const registerUsername = document.getElementById('register-username');
const registerEmail = document.getElementById('register-email');
const registerPhone = document.getElementById('register-phone');
const registerPassword = document.getElementById('register-password');
const registerReferral = document.getElementById('register-referral');
const logoutBtn = document.getElementById('logout-btn');
const logoutBtnMenu = document.getElementById('logout-btn-menu');

// User data elements
const currentBalance = document.getElementById('current-balance');
const referralCount = document.getElementById('referral-count');
const walletBalance = document.getElementById('wallet-balance');
const userReferralCode = document.getElementById('user-referral-code');
const userUid = document.getElementById('user-uid');
const accountUsername = document.getElementById('account-username');
const transactionsList = document.getElementById('transactions-list');
const walletTransactionsList = document.getElementById('wallet-transactions-list');
const totalReferralsEl = document.getElementById('total-referrals');
const successfulReferralsEl = document.getElementById('successful-referrals');
const bonusEarnedEl = document.getElementById('bonus-earned');
const pendingBonusEl = document.getElementById('pending-bonus');

// Firestore references
let userRef;
let transactionsRef;
let unsubscribeUser;
let unsubscribeTransactions;

// Initialize the app when DOM is fully loaded
document.addEventListener('DOMContentLoaded', function() {
    initApp();
});

// Initialize the app
function initApp() {
    // Check auth state
    auth.onAuthStateChanged(user => {
        if (user) {
            // User is signed in
            setupUser(user);
        } else {
            // No user is signed in
            showAuth();
        }
    });

    // Add event listeners
    addEventListeners();
    
    // Initialize slider
    initNewSlider();
}

// Show auth forms
function showAuth() {
    authContainer.style.display = 'flex';
    appContainer.style.display = 'none';
    
    // Show login form by default
    loginForm.classList.add('active');
    registerForm.classList.remove('active');
    forgotPasswordForm.classList.remove('active');
    
    // Clear forms
    loginForm.reset();
    registerForm.reset();
    forgotPasswordForm.reset();
}

// Show app
function showApp() {
    authContainer.style.display = 'none';
    appContainer.style.display = 'flex';
}

// Setup user
function setupUser(user) {
    // Set up Firestore references
    userRef = db.collection('users').doc(user.uid);
    transactionsRef = db.collection('users').doc(user.uid).collection('transactions');

    // Set up real-time listener for user data
    unsubscribeUser = userRef.onSnapshot(doc => {
        if (doc.exists) {
            const userData = doc.data();
            updateUserUI(userData);
        }
    }, error => {
        console.error("Error getting user document:", error);
        showError("Error loading user data. Please try again.");
    });

    // Set up real-time listener for transactions
    unsubscribeTransactions = transactionsRef.orderBy('date', 'desc').limit(3).onSnapshot(snapshot => {
        updateTransactionsUI(snapshot.docs);
    }, error => {
        console.error("Error getting transactions:", error);
        showError("Error loading transactions. Please try again.");
    });

    // Show the app
    showApp();
}

// Update user UI with data from Firestore
function updateUserUI(userData) {
    // Update balance
    if (currentBalance) currentBalance.textContent = `₹${userData.balance || 0}`;
    if (walletBalance) walletBalance.textContent = `₹${userData.balance || 0}`;
    
    // Update referral info
    if (referralCount) referralCount.textContent = userData.referralCount || 0;
    if (userReferralCode) userReferralCode.textContent = userData.referralCode || '';
    if (userUid) userUid.textContent = `UID: ${userData.uid || ''}`;
    if (accountUsername) accountUsername.textContent = userData.username || '';
    
    // Update referral stats
    if (totalReferralsEl) totalReferralsEl.textContent = userData.referralCount || 0;
    if (successfulReferralsEl) successfulReferralsEl.textContent = userData.successfulReferrals || 0;
    if (bonusEarnedEl) bonusEarnedEl.textContent = `₹${userData.bonusEarned || 0}`;
    if (pendingBonusEl) pendingBonusEl.textContent = `₹${userData.pendingBonus || 0}`;
}

// Update transactions UI
function updateTransactionsUI(transactions) {
    if (!transactionsList && !walletTransactionsList) return;
    
    const transactionsHTML = transactions.map(doc => {
        const transaction = doc.data();
        const date = transaction.date.toDate();
        const formattedDate = formatDate(date);
        const orderId = doc.id.substring(0, 8).toUpperCase();
        
        return `
            <div class="transaction-item ${transaction.type}">
                <div>
                    <div class="transaction-amount ${transaction.type}">
                        ${transaction.type === 'credit' ? '+' : '-'} ₹${transaction.amount}
                        ${transaction.fees ? `<span class="transaction-fees">(Fees: ₹${transaction.fees})</span>` : ''}
                    </div>
                    <div class="transaction-details">${transaction.details}</div>
                    <div class="transaction-id">Order ID: ${orderId}</div>
                </div>
                <div class="transaction-date">${formattedDate}</div>
            </div>
        `;
    }).join('');
    
    if (transactionsList) transactionsList.innerHTML = transactionsHTML;
    if (walletTransactionsList) walletTransactionsList.innerHTML = transactionsHTML;
}

// Format date
function formatDate(date) {
    const now = new Date();
    const diff = now - date;
    const diffDays = Math.floor(diff / (1000 * 60 * 60 * 24));
    
    if (diffDays === 0) {
        return `Today, ${date.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}`;
    } else if (diffDays === 1) {
        return 'Yesterday';
    } else if (diffDays < 7) {
        return `${diffDays} days ago`;
    } else {
        return date.toLocaleDateString();
    }
}

// Generate 8-digit numerical UID
function generateUID() {
    const min = 10000000;
    const max = 99999999;
    return Math.floor(min + Math.random() * (max - min + 1)).toString();
}

// Generate unique 12-character referral code
async function generateReferralCode() {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let code;
    let exists = true;
    
    // Keep generating until we find a unique code
    while (exists) {
        code = '';
        for (let i = 0; i < 12; i++) {
            code += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        
        // Check if code already exists
        const query = await db.collection('users').where('referralCode', '==', code).limit(1).get();
        exists = !query.empty;
    }
    
    return code;
}

// Handle login
function handleLogin(email, password, remember) {
    const persistence = remember ? 
        firebase.auth.Auth.Persistence.LOCAL : 
        firebase.auth.Auth.Persistence.SESSION;

    auth.setPersistence(persistence)
        .then(() => {
            return auth.signInWithEmailAndPassword(email, password);
        })
        .then((userCredential) => {
            // User logged in successfully
            showSuccessMessage('Login successful!');
        })
        .catch((error) => {
            console.error("Login error:", error);
            showError(getAuthErrorMessage(error));
        });
}

// Validate phone number
function validatePhoneNumber(phone) {
    const phoneRegex = /^[0-9]{10}$/;
    return phoneRegex.test(phone);
}

// Validate referral code format
function validateReferralCodeFormat(code) {
    const referralRegex = /^[A-Z0-9]{12}$/;
    return referralRegex.test(code);
}

// Handle registration
async function handleRegistration(username, email, phone, password, referralCode) {
    try {
        // Validate all fields
        if (!username || !email || !phone || !password) {
            throw new Error("Please fill in all required fields");
        }

        if (password.length < 6) {
            throw new Error("Password must be at least 6 characters");
        }

        if (!validatePhoneNumber(phone)) {
            throw new Error("Please enter a valid 10-digit phone number");
        }

        // Check if referral code is provided and validate format
        if (referralCode && referralCode.trim() !== '') {
            if (!validateReferralCodeFormat(referralCode)) {
                throw new Error("Referral code must be 12 characters long (A-Z, 0-9)");
            }
        }

        // Check if phone number already exists
        const phoneQuery = await db.collection('users').where('phone', '==', phone).get();
        if (!phoneQuery.empty) {
            throw new Error("Phone number already registered");
        }

        // Check if email already exists
        const emailQuery = await db.collection('users').where('email', '==', email).get();
        if (!emailQuery.empty) {
            throw new Error("Email already registered");
        }

        // If referral code is provided, validate it exists
        let referrerId = null;
        let referrerData = null;
        if (referralCode && referralCode.trim() !== '') {
            const referralQuery = await db.collection('users').where('referralCode', '==', referralCode).get();
            if (referralQuery.empty) {
                throw new Error("Invalid referral code");
            }
            referrerId = referralQuery.docs[0].id;
            referrerData = referralQuery.docs[0].data();
        }

        // Proceed with user creation
        await createUser(username, email, phone, password, referralCode, referrerId, referrerData);
        
    } catch (error) {
        console.error("Registration error:", error);
        showError(error.message);
    }
}

// Create user in Firebase Auth and Firestore
async function createUser(username, email, phone, password, referralCode = null, referrerId = null, referrerData = null) {
    try {
        // Create user in Firebase Auth
        const userCredential = await auth.createUserWithEmailAndPassword(email, password);
        const user = userCredential.user;
        
        // Generate unique UID and referral code
        const uid = generateUID();
        const referralCodeGenerated = await generateReferralCode();
        
        // Prepare user data
        const userData = {
            uid: uid,
            username: username,
            email: email,
            phone: phone,
            referralCode: referralCodeGenerated,
            balance: 15, // Default balance
            referralCount: 0,
            successfulReferrals: 0,
            bonusEarned: 0,
            pendingBonus: 0,
            joinDate: new Date(),
            hasMadeFirstDeposit: false
        };
        
        // Add referredBy if referral code was provided
        if (referralCode) {
            userData.referredBy = referralCode;
            
            // Add referrer info for tracking
            userData.referrerInfo = {
                referrerId: referrerId,
                referrerName: referrerData?.username || '',
                referrerCode: referralCode,
                referralDate: new Date()
            };
        }
        
        // Create user document in Firestore
        await db.collection('users').doc(user.uid).set(userData);
        
        // If referral code was provided, update the referrer's count
        if (referrerId) {
            await db.collection('users').doc(referrerId).update({
                referralCount: firebase.firestore.FieldValue.increment(1),
                pendingBonus: firebase.firestore.FieldValue.increment(35)
            });
            
            // Add referral record to referrer's subcollection
            await db.collection('users').doc(referrerId).collection('referrals').add({
                referredUserId: user.uid,
                referredUserName: username,
                referredUserEmail: email,
                referralCodeUsed: referralCode,
                date: new Date(),
                status: 'pending',
                potentialBonus: 35
            });
        }
        
        // Show success message
        showSuccessMessage('Registration successful!');
        registerForm.reset();
        loginForm.classList.add('active');
        registerForm.classList.remove('active');
        
    } catch (error) {
        console.error("Error in createUser:", error);
        throw error;
    }
}

// Handle forgot password
function handleForgotPassword(email) {
    auth.sendPasswordResetEmail(email, {
        url: window.location.href, // Redirect URL after password reset
        handleCodeInApp: true // Handle the password reset in the app
    })
    .then(() => {
        showSuccessMessage('Password reset email sent! Check your inbox (and spam folder).');
        forgotPasswordForm.reset();
        loginForm.classList.add('active');
        forgotPasswordForm.classList.remove('active');
    })
    .catch((error) => {
        console.error("Forgot password error:", error);
        showError(getAuthErrorMessage(error));
    });
}

// Handle logout
function handleLogout() {
    // Unsubscribe from listeners
    if (unsubscribeUser) unsubscribeUser();
    if (unsubscribeTransactions) unsubscribeTransactions();
    
    auth.signOut()
        .then(() => {
            showAuth();
        })
        .catch((error) => {
            console.error("Logout error:", error);
            showError(error.message);
        });
}

// Get user-friendly auth error messages
function getAuthErrorMessage(error) {
    switch(error.code) {
        case 'auth/invalid-email':
            return 'Invalid email address';
        case 'auth/user-disabled':
            return 'Account disabled';
        case 'auth/user-not-found':
            return 'Account not found';
        case 'auth/wrong-password':
            return 'Incorrect password';
        case 'auth/email-already-in-use':
            return 'Email already in use';
        case 'auth/weak-password':
            return 'Password should be at least 6 characters';
        case 'auth/operation-not-allowed':
            return 'Operation not allowed';
        case 'auth/too-many-requests':
            return 'Too many requests. Try again later';
        default:
            return error.message || 'An error occurred. Please try again';
    }
}

// Show error message
function showError(message) {
    // Remove any existing error messages
    const existingErrors = document.querySelectorAll('.error-message');
    existingErrors.forEach(err => err.remove());
    
    // Create new error element
    const errorElement = document.createElement('div');
    errorElement.className = 'error-message';
    errorElement.textContent = message;
    
    // Add to active form
    const activeForm = document.querySelector('.auth-form.active');
    if (activeForm) {
        activeForm.insertBefore(errorElement, activeForm.lastElementChild);
    }
}

// Show success message
function showSuccessMessage(message) {
    const successMessage = document.getElementById('success-message');
    if (!successMessage) return;
    
    successMessage.innerHTML = `<i class="fas fa-check-circle"></i> ${message}`;
    successMessage.classList.add('show');
    setTimeout(() => {
        successMessage.classList.remove('show');
    }, 3000);
}

// Initialize new slider
function initNewSlider() {
    const newSlider = document.querySelector('.new-slider');
    const newSlides = document.querySelectorAll('.new-slide');
    const newIndicators = document.querySelectorAll('.new-indicator');
    
    if (!newSlider || !newSlides.length) return;
    
    let currentSlide = 0;
    let slideInterval;
    
    // Start auto sliding
    startNewSlider();
    
    // Set initial slide
    goToNewSlide(0);
    
    function startNewSlider() {
        // Clear any existing interval
        if (slideInterval) clearInterval(slideInterval);
        
        // Set new interval (5 seconds)
        slideInterval = setInterval(() => {
            goToNewSlide(currentSlide + 1);
        }, 5000);
    }
    
    function goToNewSlide(n) {
        // Wrap around if at end
        currentSlide = (n + newSlides.length) % newSlides.length;
        
        // Update slider position
        newSlider.style.transform = `translateX(-${currentSlide * 100}%)`;
        
        // Update indicators
        updateNewIndicators();
    }
    
    function updateNewIndicators() {
        if (!newIndicators.length) return;
        
        newIndicators.forEach((indicator, index) => {
            if (index === currentSlide) {
                indicator.classList.add('active');
            } else {
                indicator.classList.remove('active');
            }
        });
    }
    
    // Indicator click events
    if (newIndicators.length) {
        newIndicators.forEach((indicator, index) => {
            indicator.addEventListener('click', () => {
                // Reset auto-slide timer when manually changing slide
                if (slideInterval) clearInterval(slideInterval);
                goToNewSlide(index);
                startNewSlider();
            });
        });
    }
}

// Change page
function changePage(pageId) {
    const pages = document.querySelectorAll('.page');
    if (!pages.length) return;
    
    // Hide all pages
    pages.forEach(page => {
        page.classList.remove('active');
    });
    
    // Show selected page
    const page = document.getElementById(pageId);
    if (page) page.classList.add('active');
}

// Add event listeners
function addEventListeners() {
    // Show register form
    if (showRegister) {
        showRegister.addEventListener('click', (e) => {
            e.preventDefault();
            loginForm.classList.remove('active');
            forgotPasswordForm.classList.remove('active');
            registerForm.classList.add('active');
        });
    }
    
    // Show login form
    if (showLogin) {
        showLogin.addEventListener('click', (e) => {
            e.preventDefault();
            registerForm.classList.remove('active');
            forgotPasswordForm.classList.remove('active');
            loginForm.classList.add('active');
        });
    }
    
    // Show forgot password form
    if (forgotPasswordLink) {
        forgotPasswordLink.addEventListener('click', (e) => {
            e.preventDefault();
            loginForm.classList.remove('active');
            registerForm.classList.remove('active');
            forgotPasswordForm.classList.add('active');
        });
    }
    
    // Show login from forgot password
    if (showLoginFromForgot) {
        showLoginFromForgot.addEventListener('click', (e) => {
            e.preventDefault();
            forgotPasswordForm.classList.remove('active');
            registerForm.classList.remove('active');
            loginForm.classList.add('active');
        });
    }
    
    // Login form submission
    if (loginForm) {
        loginForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const email = loginEmail.value.trim();
            const password = loginPassword.value.trim();
            const remember = rememberMe.checked;
            
            if (email && password) {
                handleLogin(email, password, remember);
            } else {
                showError("Please fill in all fields");
            }
        });
    }
    
    // Register form submission
    if (registerForm) {
        registerForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const username = registerUsername.value.trim();
            const email = registerEmail.value.trim();
            const phone = registerPhone.value.trim();
            const password = registerPassword.value.trim();
            const referral = registerReferral.value.trim();
            
            handleRegistration(username, email, phone, password, referral);
        });
    }
    
    // Forgot password form submission
    if (forgotPasswordForm) {
        forgotPasswordForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const email = resetEmail.value.trim();
            
            if (email) {
                handleForgotPassword(email);
            } else {
                showError("Please enter your email");
            }
        });
    }
    
    // Logout buttons
    if (logoutBtn) {
        logoutBtn.addEventListener('click', handleLogout);
    }
    if (logoutBtnMenu) {
        logoutBtnMenu.addEventListener('click', (e) => {
            e.preventDefault();
            handleLogout();
        });
    }
    
    // Copy referral code button
    const copyReferralBtn = document.getElementById('copy-referral-btn');
    if (copyReferralBtn) {
        copyReferralBtn.addEventListener('click', () => {
            const code = userReferralCode.textContent;
            if (code && code !== 'Loading...') {
                navigator.clipboard.writeText(code).then(() => {
                    showSuccessMessage('Referral code copied!');
                });
            }
        });
    }
    
    // Copy UID button
    const copyUidBtn = document.getElementById('copy-uid-btn');
    if (copyUidBtn) {
        copyUidBtn.addEventListener('click', () => {
            const uid = userUid.textContent.replace('UID: ', '');
            if (uid && uid !== 'Loading...') {
                navigator.clipboard.writeText(uid).then(() => {
                    showSuccessMessage('UID copied!');
                });
            }
        });
    }
    
    // Wallet actions
    const addMoneyBtn = document.getElementById('add-money');
    if (addMoneyBtn) {
        addMoneyBtn.addEventListener('click', () => {
            const addMoneyModal = document.getElementById('add-money-modal');
            if (addMoneyModal) addMoneyModal.classList.add('active');
        });
    }
    
    const withdrawBtn = document.getElementById('withdraw');
    if (withdrawBtn) {
        withdrawBtn.addEventListener('click', () => {
            const withdrawModal = document.getElementById('withdraw-modal');
            if (withdrawModal) withdrawModal.classList.add('active');
        });
    }
    
    // Deposit submit button
    const depositSubmitBtn = document.getElementById('deposit-submit-btn');
    if (depositSubmitBtn) {
        depositSubmitBtn.addEventListener('click', async (e) => {
            e.preventDefault();
            const amountInput = document.getElementById('deposit-amount');
            const amount = parseFloat(amountInput.value);
            
            if (amount && amount >= 100) {
                const user = auth.currentUser;
                if (user) {
                    // Show loading state
                    depositSubmitBtn.innerHTML = '<span class="loading-spinner"></span> Processing...';
                    depositSubmitBtn.disabled = true;
                    
                    try {
                        // Update balance
                        await db.collection('users').doc(user.uid).update({
                            balance: firebase.firestore.FieldValue.increment(amount)
                        });
                        
                        // Add transaction
                        await db.collection('users').doc(user.uid).collection('transactions').add({
                            amount: amount,
                            type: 'credit',
                            details: 'Deposit',
                            date: new Date()
                        });
                        
                        showSuccessMessage(`Deposit of ₹${amount} successful!`);
                        const addMoneyModal = document.getElementById('add-money-modal');
                        if (addMoneyModal) addMoneyModal.classList.remove('active');
                        amountInput.value = '';
                        
                        // Check if this is first deposit and user was referred
                        await checkFirstDepositBonus(user.uid);
                    } catch (error) {
                        console.error("Error processing deposit:", error);
                        showSuccessMessage('Error processing deposit');
                    } finally {
                        depositSubmitBtn.innerHTML = 'Proceed';
                        depositSubmitBtn.disabled = false;
                    }
                }
            } else {
                showSuccessMessage('Minimum deposit amount is ₹100');
            }
        });
    }
    
    // Check first deposit for referral bonus
    async function checkFirstDepositBonus(userId) {
        try {
            const userDoc = await db.collection('users').doc(userId).get();
            if (userDoc.exists) {
                const userData = userDoc.data();
                
                // Check if this is first deposit and user has a referrer
                if (userData.referredBy && !userData.hasMadeFirstDeposit) {
                    // Mark user as having made first deposit
                    await db.collection('users').doc(userId).update({
                        hasMadeFirstDeposit: true
                    });
                    
                    // Find referrer by referral code
                    const referralQuery = await db.collection('users').where('referralCode', '==', userData.referredBy).get();
                    
                    if (!referralQuery.empty) {
                        const referrerDoc = referralQuery.docs[0];
                        const referrerId = referrerDoc.id;
                        const bonusAmount = 35;
                        
                        // Update referrer's stats and add bonus
                        await db.collection('users').doc(referrerId).update({
                            successfulReferrals: firebase.firestore.FieldValue.increment(1),
                            bonusEarned: firebase.firestore.FieldValue.increment(bonusAmount),
                            pendingBonus: firebase.firestore.FieldValue.increment(-bonusAmount),
                            balance: firebase.firestore.FieldValue.increment(bonusAmount)
                        });
                        
                        // Add transaction for referrer
                        await db.collection('users').doc(referrerId).collection('transactions').add({
                            amount: bonusAmount,
                            type: 'credit',
                            details: 'Referral Bonus',
                            date: new Date()
                        });
                        
                        // Update referral record status
                        const referralRecords = await db.collection('users').doc(referrerId)
                            .collection('referrals')
                            .where('referredUserId', '==', userId)
                            .get();
                            
                        if (!referralRecords.empty) {
                            const referralRecordId = referralRecords.docs[0].id;
                            await db.collection('users').doc(referrerId)
                                .collection('referrals')
                                .doc(referralRecordId)
                                .update({
                                    status: 'completed',
                                    bonusPaid: bonusAmount,
                                    completionDate: new Date()
                                });
                        }
                        
                        showSuccessMessage('Referral bonus processed successfully!');
                    }
                }
            }
        } catch (error) {
            console.error("Error processing referral bonus:", error);
        }
    }
    
    // Withdraw submit button
    const withdrawSubmitBtn = document.getElementById('withdraw-submit-btn');
    if (withdrawSubmitBtn) {
        withdrawSubmitBtn.addEventListener('click', async (e) => {
            e.preventDefault();
            const amountInput = document.getElementById('withdraw-amount');
            const amount = parseFloat(amountInput.value);
            const user = auth.currentUser;
            
            if (!user) {
                showSuccessMessage('You must be logged in to withdraw');
                return;
            }
            
            if (amount && amount >= 109) {
                // Show loading state
                withdrawSubmitBtn.innerHTML = '<span class="loading-spinner"></span> Processing...';
                withdrawSubmitBtn.disabled = true;
                
                try {
                    // First check if user has sufficient balance
                    const userDoc = await db.collection('users').doc(user.uid).get();
                    
                    if (userDoc.exists) {
                        const userData = userDoc.data();
                        if (userData.balance >= amount) {
                            const withdrawalAmount = 100; // User gets ₹100
                            const fees = 9; // Withdrawal fee ₹9
                            
                            // Process withdrawal
                            await db.collection('users').doc(user.uid).update({
                                balance: firebase.firestore.FieldValue.increment(-amount)
                            });
                            
                            // Add transaction
                            await db.collection('users').doc(user.uid).collection('transactions').add({
                                amount: withdrawalAmount,
                                fees: fees,
                                type: 'debit',
                                details: 'Withdrawal',
                                date: new Date()
                            });
                            
                            showSuccessMessage(`Withdrawal request of ₹${withdrawalAmount} submitted! (Fees: ₹${fees})`);
                            const withdrawModal = document.getElementById('withdraw-modal');
                            if (withdrawModal) withdrawModal.classList.remove('active');
                            amountInput.value = '';
                        } else {
                            showSuccessMessage('Insufficient balance');
                        }
                    }
                } catch (error) {
                    console.error("Error processing withdrawal:", error);
                    showSuccessMessage('Error processing withdrawal');
                } finally {
                    withdrawSubmitBtn.innerHTML = 'Request Withdrawal';
                    withdrawSubmitBtn.disabled = false;
                }
            } else {
                showSuccessMessage('Minimum withdrawal amount is ₹109 (You get ₹100 after fees)');
            }
        });
    }
    
    // Refresh balance button
    const refreshBalanceBtn = document.getElementById('refresh-balance');
    if (refreshBalanceBtn) {
        refreshBalanceBtn.addEventListener('click', () => {
            refreshBalanceBtn.classList.add('spin');
            setTimeout(() => {
                refreshBalanceBtn.classList.remove('spin');
                showSuccessMessage('Balance refreshed');
            }, 1000);
        });
    }
    
    // Close modal buttons
    const closeModalBtns = document.querySelectorAll('.close-btn');
    if (closeModalBtns.length) {
        closeModalBtns.forEach(btn => {
            btn.addEventListener('click', () => {
                const activeModal = document.querySelector('.modal-overlay.active');
                if (activeModal) activeModal.classList.remove('active');
            });
        });
    }
    
    // Close modal when clicking outside
    document.querySelectorAll('.modal-overlay').forEach(modal => {
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                modal.classList.remove('active');
            }
        });
    });
    
    // Withdrawal method change
    const withdrawMethodSelect = document.getElementById('withdraw-method');
    if (withdrawMethodSelect) {
        withdrawMethodSelect.addEventListener('change', (e) => {
            const upiFields = document.getElementById('upi-fields');
            const bankFields = document.getElementById('bank-fields');
            
            if (e.target.value === 'upi') {
                upiFields.style.display = 'block';
                bankFields.style.display = 'none';
            } else {
                upiFields.style.display = 'none';
                bankFields.style.display = 'block';
            }
        });
    }
    
    // Payment method options
    const paymentMethodOptions = document.querySelectorAll('.payment-method-option');
    if (paymentMethodOptions.length) {
        paymentMethodOptions.forEach(option => {
            option.addEventListener('click', () => {
                paymentMethodOptions.forEach(opt => opt.classList.remove('active'));
                option.classList.add('active');
                const input = option.querySelector('input');
                if (input) input.checked = true;
            });
        });
    }
    
    // Account menu items
    const accountMenuItems = document.querySelectorAll('.account-menu a');
    if (accountMenuItems.length) {
        accountMenuItems.forEach(item => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                const id = item.id;
                
                switch(id) {
                    case 'profile-btn':
                        showSuccessMessage('Profile page will be implemented soon');
                        break;
                    case 'bank-details-btn':
                        showSuccessMessage('Bank details page will be implemented soon');
                        break;
                    case 'refer-earn-btn':
                        const promotionsNavItem = document.querySelector('.bottom-nav .nav-item[data-page="promotions-page"]');
                        if (promotionsNavItem) promotionsNavItem.click();
                        break;
                    case 'game-history-btn':
                        showSuccessMessage('Game history will be implemented soon');
                        break;
                    case 'security-btn':
                        showSuccessMessage('Security settings will be implemented soon');
                        break;
                    case 'kyc-btn':
                        showSuccessMessage('KYC verification will be implemented soon');
                        break;
                    case 'support-btn':
                        showSuccessMessage('Support page will be implemented soon');
                        break;
                }
            });
        });
    }
    
    // Language selector
    const languageSelect = document.getElementById('language-select');
    if (languageSelect) {
        languageSelect.addEventListener('change', (e) => {
            showSuccessMessage(`Language changed to ${e.target.options[e.target.selectedIndex].text}`);
        });
    }
    
    // Bottom navigation
    const bottomNavItems = document.querySelectorAll('.bottom-nav .nav-item');
    if (bottomNavItems.length) {
        bottomNavItems.forEach(item => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                const pageId = item.getAttribute('data-page');
                
                // Remove active class from all items
                bottomNavItems.forEach(navItem => {
                    navItem.classList.remove('active');
                });
                
                // Add active class to clicked item
                item.classList.add('active');
                
                // Change page
                changePage(pageId);
            });
        });
    }
    
    // View all transactions
    const viewAllLink = document.querySelector('.view-all-link');
    if (viewAllLink) {
        viewAllLink.addEventListener('click', (e) => {
            e.preventDefault();
            const user = auth.currentUser;
            if (user) {
                db.collection('users').doc(user.uid).collection('transactions')
                    .orderBy('date', 'desc')
                    .get()
                    .then(snapshot => {
                        updateTransactionsUI(snapshot.docs);
                        showSuccessMessage('Showing all transactions');
                    })
                    .catch(error => {
                        console.error("Error loading all transactions:", error);
                        showSuccessMessage('Error loading transactions');
                    });
            }
        });
    }
}

// Add spin animation for refresh button
const style = document.createElement('style');
style.textContent = `
    @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
    }
    .spin {
        animation: spin 0.7s linear;
    }
    .transaction-fees {
        font-size: 0.7rem;
        color: var(--light-text);
        margin-left: 0.5rem;
    }
    .transaction-id {
        font-size: 0.7rem;
        color: var(--light-text);
        margin-top: 0.2rem;
    }
`;
document.head.appendChild(style);