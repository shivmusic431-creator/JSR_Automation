// Premium Quality Wingo Game for SR777 CLUB
let timeLeft = 30;
let results = [];
let timerInterval;
let periodCounter = 201024001;
let walletBalance = 5000000; // Set initial balance to ₹5,000,000
let userBets = [];
let userBetHistory = [];
let currentPage = 0;
let myBetCurrentPage = 0;
const resultsPerPage = 10;
const betsPerPage = 10;
let activeChartTab = 'current';
let soundEnabled = true;

// Track game statistics
let gameStats = {
  totalBets: 0,
  totalWins: 0,
  totalAmountWon: 0,
  biggestWin: 0,
  winStreak: 0,
  currentStreak: 0
};

// Track bets for current and previous periods
let currentPeriodBets = {
  green: 0,
  red: 0,
  violet: 0,
  big: 0,
  small: 0,
  number: 0
};

let previousPeriodsBets = [];
let winningNumbers = {};

// Simulated global bets for all users (for chart)
let globalBets = {
  current: { green: 0, red: 0, violet: 0, big: 0, small: 0, number: 0 },
  prev1: { green: 0, red: 0, violet: 0, big: 0, small: 0, number: 0 },
  prev2: { green: 0, red: 0, violet: 0, big: 0, small: 0, number: 0 }
};

// Sound effects
const sounds = {
  countdown: new Audio('countdownn.mp3'),
  win: new Audio('win.mp3'),
  lose: new Audio('lose.mp3'),
  betPlaced: new Audio('bet.mp3'),
  timerEnd: new Audio('timerend.mp3')
};

// Constants for multipliers
const MULTIPLIERS = {
  COLOR_WIN: 1.90,
  VIOLET_WIN: 4.40,
  NUMBER_WIN: 8.10,
  SPECIAL_COLOR_WIN: 1.5
};

// Initialize the game
function initGame() {
  const savedState = localStorage.getItem('wingoGameState');
  if (savedState) {
    const state = JSON.parse(savedState);
    results = state.results || [];
    periodCounter = state.periodCounter || 201024001;
    walletBalance = state.walletBalance || 5000000; // Load saved balance or default to ₹5,000,000
    gameStats = state.gameStats || {
      totalBets: 0,
      totalWins: 0,
      totalAmountWon: 0,
      biggestWin: 0,
      winStreak: 0,
      currentStreak: 0
    };
    globalBets = state.globalBets || {
      current: { green: 0, red: 0, violet: 0, big: 0, small: 0, number: 0 },
      prev1: { green: 0, red: 0, violet: 0, big: 0, small: 0, number: 0 },
      prev2: { green: 0, red: 0, violet: 0, big: 0, small: 0, number: 0 }
    };
    userBetHistory = state.userBetHistory || [];
  }
  
  const soundPref = localStorage.getItem('soundEnabled');
  if (soundPref !== null) {
    soundEnabled = soundPref === 'true';
    updateSoundIcon();
  }
  
  startTimer();
  updateWingoNumbers();
  updateHistory();
  updateMyBetHistory();
  updateNextPeriod();
  updateChartSection();
  updatePortfolio();
}

// Start the timer
function startTimer() {
  clearInterval(timerInterval);
  timerInterval = setInterval(() => {
    const timerElement = document.getElementById('timer');
    if (timerElement) {
      timerElement.innerText = `00:${timeLeft < 10 ? '0' : ''}${timeLeft}`;
    }

    if (timeLeft === 5) {
      playSound('countdown');
      showCountdownOverlay();
      closeBattingSlide();
    }

    timeLeft--;

    if (timeLeft < 0) {
      playSound('timerEnd');
      timeLeft = 30;
      generateRandomNumber();
    }
  }, 1000);
}

// Generate a random number and update results
function generateRandomNumber() {
  const number = Math.floor(Math.random() * 10);
  const colorClass = getColorClass(number);
  
  winningNumbers[periodCounter] = number;

  if (Object.values(currentPeriodBets).some(amt => amt > 0)) {
    previousPeriodsBets.unshift({
      period: periodCounter,
      bets: { ...currentPeriodBets },
      number: number
    });
    
    if (previousPeriodsBets.length > 2) {
      previousPeriodsBets.pop();
    }
  }

  globalBets.prev2 = { ...globalBets.prev1 };
  globalBets.prev1 = { ...globalBets.current };
  globalBets.current = { green: 0, red: 0, violet: 0, big: 0, small: 0, number: 0 };

  currentPeriodBets = {
    green: 0,
    red: 0,
    violet: 0,
    big: 0,
    small: 0,
    number: 0
  };

  results.unshift({ 
    number, 
    colorClass, 
    period: periodCounter
  });
  
  gameStats.totalBets += userBets.length;
  
  periodCounter++;
  
  updateWingoNumbers();
  updateHistory();
  updateMyBetHistory();
  updateNextPeriod();
  checkBettingResult();
  updateChartSection();
  updatePortfolio();
  
  saveGameState();
}

// Get the color class for a number
function getColorClass(number) {
  if (number === 0 || number === 5) return 'violet';
  return number % 2 === 0 ? 'red' : 'green';
}

// Update Wingo numbers (latest 5 results)
function updateWingoNumbers() {
  const wingoDiv = document.getElementById('wingo-numbers');
  if (!wingoDiv) return;

  wingoDiv.innerHTML = '';
  const latestResults = results.slice(0, 5);
  
  if (latestResults.length === 0) return;
  
  latestResults.forEach(result => {
    const numberCircle = document.createElement('div');
    numberCircle.classList.add('number-ball', result.colorClass);

    const numberImage = document.createElement('img');
    numberImage.src = `no${result.number}.png`;
    numberImage.alt = result.number.toString();
    numberImage.onerror = () => { numberImage.style.display = 'none' };

    numberCircle.appendChild(numberImage);
    wingoDiv.appendChild(numberCircle);
  });
}

// Update the results history with proper pagination
function updateHistory() {
  const historyDiv = document.getElementById('results-history');
  if (!historyDiv) return;
  
  historyDiv.innerHTML = '';
  
  const start = currentPage * resultsPerPage;
  const end = start + resultsPerPage;
  const pageResults = results.slice(start, end);

  if (pageResults.length === 0 && currentPage > 0) {
    currentPage = Math.max(0, Math.ceil(results.length / resultsPerPage) - 1);
    updateHistory();
    return;
  }

  if (pageResults.length === 0) {
    historyDiv.innerHTML = '<div class="no-data">No results available</div>';
    return;
  }

  pageResults.forEach(result => {
    const historyRow = document.createElement('div');
    historyRow.classList.add('history-row');

    const numberColorClass = result.number === 0 ? 'number-violet' :
      result.number === 5 ? 'number-green number-violet' :
      [1, 3, 7, 9].includes(result.number) ? 'number-green' : 'number-red';

    historyRow.innerHTML = `
      <div class="history-period">${result.period}</div>
      <div class="history-number ${numberColorClass}">${result.number}</div>
      <div class="history-bigsmall">${result.number >= 5 ? 'Big' : 'Small'}</div>
    `;
    historyDiv.appendChild(historyRow);
  });

  updateNavigationButtons();
  updatePageInfo();
}

// Update the My Bet history with pagination
function updateMyBetHistory() {
  const myBetHistoryDiv = document.getElementById('mybet-history');
  if (!myBetHistoryDiv) return;

  myBetHistoryDiv.innerHTML = '';

  const start = myBetCurrentPage * betsPerPage;
  const end = start + betsPerPage;
  const pageBets = userBetHistory.slice(start, end);

  if (pageBets.length === 0 && myBetCurrentPage > 0) {
    myBetCurrentPage = Math.max(0, Math.ceil(userBetHistory.length / betsPerPage) - 1);
    updateMyBetHistory();
    return;
  }

  if (pageBets.length === 0) {
    myBetHistoryDiv.innerHTML = '<div class="no-data">No bets placed yet</div>';
    return;
  }

  pageBets.forEach(bet => {
    const betRow = document.createElement('div');
    betRow.classList.add('mybet-row');

    let iconClass, iconContent;
    if (['Green', 'Red', 'Violet', 'Big', 'Small'].includes(bet.option)) {
      iconClass = bet.option.toLowerCase();
      iconContent = bet.option.charAt(0);
    } else {
      iconClass = 'violet';
      iconContent = bet.option;
    }

    const betDate = new Date(bet.timestamp);
    const formattedDateTime = `${betDate.toLocaleDateString()} ${betDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;

    let resultClass, resultText;
    if (bet.status === 'Pending') {
      resultClass = 'pending';
      resultText = 'Pending';
    } else if (bet.status === 'Win') {
      resultClass = 'win';
      resultText = `+₹${bet.winAmount.toFixed(2)}`;
    } else {
      resultClass = 'loss';
      resultText = `-₹${bet.amount.toFixed(2)}`;
    }

    betRow.innerHTML = `
      <div class="bet-icon"><span class="icon ${iconClass}">${iconContent}</span></div>
      <div class="period-info">
        <div class="period-no">${bet.period}</div>
        <div class="date-time">${formattedDateTime}</div>
      </div>
      <div class="bet-result ${resultClass}">${resultText}</div>
    `;
    myBetHistoryDiv.appendChild(betRow);
  });

  updateMyBetNavigationButtons();
  updateMyBetPageInfo();
}

// Update the next period number
function updateNextPeriod() {
  const nextPeriod = document.getElementById('period-number');
  if (nextPeriod) nextPeriod.innerText = periodCounter;
}

// Open the betting slide
function openBattingSlide(selectedOption) {
  const battingOverlay = document.getElementById('battingOverlay');
  const selectedOptionText = document.getElementById('selectedOption');
  if (!battingOverlay || !selectedOptionText) return;

  selectedOptionText.innerText = `Selected: ${selectedOption}`;
  battingOverlay.style.display = 'flex';
  setTimeout(() => battingOverlay.classList.add('active'), 10);
  
  const betAmountInput = document.getElementById('betAmount');
  if (betAmountInput) {
    betAmountInput.value = '';
    betAmountInput.focus();
  }
}

// Close the betting slide
function closeBattingSlide() {
  const battingOverlay = document.getElementById('battingOverlay');
  if (!battingOverlay) return;

  battingOverlay.classList.remove('active');
  setTimeout(() => {
    if (!battingOverlay.classList.contains('active')) {
      battingOverlay.style.display = 'none';
    }
  }, 300);
}

// Show toast notification
function showToast(message) {
  const toast = document.createElement('div');
  toast.classList.add('toast-notification');
  toast.innerHTML = `<div class="toast-content">${message}</div>`;
  document.body.appendChild(toast);

  setTimeout(() => toast.classList.add('show'), 10);
  setTimeout(() => {
    toast.classList.remove('show');
    setTimeout(() => toast.remove(), 300);
  }, 3000);
}

// Show custom alert
function showAlert(message, backgroundImage, isWin, winningNumber = null, winningColor = null, won = null, periodNo = null) {
  const alertBox = document.createElement('div');
  alertBox.classList.add('custom-alert');
  alertBox.style.backgroundImage = `url(${backgroundImage})`;

  alertBox.innerHTML = isWin ? `
    <div class="alert-message">
      <h1>Congratulations</h1>
      <p class="Result">Result: ${winningNumber} (${winningColor})</p>
      <p class="Won">Won: ₹${won.toFixed(2)}</p>
      <p class="period-no">Period no: ${periodNo}</p>
    </div>
  ` : `
    <div class="alert-message">
      <h1>Sorry</h1>
      <p>You didn't win this time.</p>
    </div>
  `;

  document.body.appendChild(alertBox);
  
  if (isWin) {
    playSound('win');
  } else {
    playSound('lose');
  }
  
  setTimeout(() => {
    alertBox.style.opacity = '0';
    setTimeout(() => alertBox.remove(), 300);
  }, 5000);
}

// Check betting result after each round
function checkBettingResult() {
  if (userBets.length === 0) return;

  const latestResult = results[0];
  let totalWinAmount = 0;
  let hasWon = false;

  userBets.forEach(bet => {
    let winAmount = 0;
    const isBig = bet.option === "Big" && latestResult.number >= 5;
    const isSmall = bet.option === "Small" && latestResult.number < 5;
    const isRed = bet.option === "Red" && latestResult.colorClass === "red";
    const isGreen = bet.option === "Green" && latestResult.colorClass === "green";
    const isViolet = bet.option === "Violet" && latestResult.colorClass === "violet";
    const isNumber = parseInt(bet.option) === latestResult.number;

    if (isBig || isSmall || (isRed && latestResult.number !== 5) || (isGreen && latestResult.number !== 0)) {
      winAmount = bet.amount * MULTIPLIERS.COLOR_WIN;
    } else if ((isRed && latestResult.number === 0) || (isGreen && latestResult.number === 5)) {
      winAmount = bet.amount * MULTIPLIERS.SPECIAL_COLOR_WIN;
    } else if (isViolet) {
      winAmount = bet.amount * MULTIPLIERS.VIOLET_WIN;
    } else if (isNumber) {
      winAmount = bet.amount * MULTIPLIERS.NUMBER_WIN;
    }

    const betIndex = userBetHistory.findIndex(b => 
      b.period === bet.period && b.option === bet.option && b.amount === bet.amount && b.status === 'Pending'
    );
    if (betIndex !== -1) {
      if (winAmount > 0) {
        userBetHistory[betIndex].status = 'Win';
        userBetHistory[betIndex].winAmount = winAmount;
      } else {
        userBetHistory[betIndex].status = 'Loss';
      }
    }

    if (winAmount > 0) {
      walletBalance += winAmount;
      totalWinAmount += winAmount;
      hasWon = true;
      
      gameStats.totalWins++;
      gameStats.totalAmountWon += winAmount;
      gameStats.currentStreak++;
      
      if (winAmount > gameStats.biggestWin) {
        gameStats.biggestWin = winAmount;
      }
      
      if (gameStats.currentStreak > gameStats.winStreak) {
        gameStats.winStreak = gameStats.currentStreak;
      }
    } else {
      gameStats.currentStreak = 0;
    }
  });

  if (hasWon) {
    showAlert(`You Won\n₹${totalWinAmount.toFixed(2)}`, 'win.png', true, latestResult.number, latestResult.colorClass, totalWinAmount, latestResult.period);
  } else {
    showAlert("Didn't Win", 'loss.png', false);
  }

  userBets = [];
  updateWalletBalance();
  updateMyBetHistory();
  saveGameState();
}

function updateWalletBalance() {
  const walletBalanceBox = document.getElementById('walletBalanceBox');
  if (walletBalanceBox) walletBalanceBox.innerText = ` ₹${walletBalance.toLocaleString()}`;
}

// Update navigation buttons state for History
function updateNavigationButtons() {
  const previousBtn = document.getElementById('previous-btn');
  const nextBtn = document.getElementById('next-btn');
  if (!previousBtn || !nextBtn) return;

  previousBtn.disabled = currentPage === 0;
  nextBtn.disabled = (currentPage + 1) * resultsPerPage >= results.length;
}

// Update navigation buttons state for My Bet
function updateMyBetNavigationButtons() {
  const previousBtn = document.getElementById('mybet-previous-btn');
  const nextBtn = document.getElementById('mybet-next-btn');
  if (!previousBtn || !nextBtn) return;

  previousBtn.disabled = myBetCurrentPage === 0;
  nextBtn.disabled = (myBetCurrentPage + 1) * betsPerPage >= userBetHistory.length;
}

// Show previous/next page for History
function showPreviousPage() {
  if (currentPage > 0) {
    currentPage--;
    updateHistory();
  }
}

function showNextPage() {
  if ((currentPage + 1) * resultsPerPage < results.length) {
    currentPage++;
    updateHistory();
  }
}

// Show previous/next page for My Bet
function showPreviousMyBetPage() {
  if (myBetCurrentPage > 0) {
    myBetCurrentPage--;
    updateMyBetHistory();
  }
}

function showNextMyBetPage() {
  if ((myBetCurrentPage + 1) * betsPerPage < userBetHistory.length) {
    myBetCurrentPage++;
    updateMyBetHistory();
  }
}

// Show countdown overlay
function showCountdownOverlay() {
  const gameBox = document.querySelector('.game-box');
  if (!gameBox) return;

  const countdownOverlay = document.createElement('div');
  countdownOverlay.classList.add('countdown-overlay');
  countdownOverlay.innerHTML = `<div class="countdown-timer">5</div>`;
  gameBox.appendChild(countdownOverlay);

  let countdown = 5;
  const countdownInterval = setInterval(() => {
    countdown--;
    countdownOverlay.querySelector('.countdown-timer').innerText = countdown;
    if (countdown <= 0) {
      clearInterval(countdownInterval);
      countdownOverlay.remove();
    }
  }, 1000);
}

// Switch between sections
function switchSection(section) {
  const sections = ['results-history', 'chart-section', 'portfolio-section', 'mybet-section', 'history-navigation', 'mybet-navigation'];
  sections.forEach(id => {
    const element = document.getElementById(id);
    if (element) element.style.display = 'none';
  });

  if (section === 'history') {
    const history = document.getElementById('results-history');
    const navigation = document.getElementById('history-navigation');
    if (history) history.style.display = 'block';
    if (navigation) navigation.style.display = 'flex';
  } else if (section === 'chart') {
    const chart = document.getElementById('chart-section');
    if (chart) chart.style.display = 'block';
  } else if (section === 'portfolio') {
    const portfolio = document.getElementById('portfolio-section');
    if (portfolio) portfolio.style.display = 'block';
  } else if (section === 'mybet') {
    const mybet = document.getElementById('mybet-section');
    const navigation = document.getElementById('mybet-navigation');
    if (mybet) mybet.style.display = 'block';
    if (navigation) navigation.style.display = 'flex';
  }

  document.querySelectorAll('.section-btn').forEach(btn => btn.classList.remove('active'));
  const activeBtn = document.getElementById(`${section}-btn`);
  if (activeBtn) activeBtn.classList.add('active');
}

// Update chart section with real betting data
function updateChartSection() {
  document.getElementById('current-period').innerText = periodCounter;
  
  if (previousPeriodsBets.length > 0) {
    document.getElementById('prev1-period').innerText = previousPeriodsBets[0].period;
    updateStatsBox('prev1-stats', previousPeriodsBets[0].bets, previousPeriodsBets[0].number);
  } else {
    document.getElementById('prev1-stats').innerHTML = '<div class="no-bets">No bets in this period</div>';
  }
  
  if (previousPeriodsBets.length > 1) {
    document.getElementById('prev2-period').innerText = previousPeriodsBets[1].period;
    updateStatsBox('prev2-stats', previousPeriodsBets[1].bets, previousPeriodsBets[1].number);
  } else {
    document.getElementById('prev2-stats').innerHTML = '<div class="no-bets">No bets in this period</div>';
  }
  
  if (Object.values(currentPeriodBets).some(amt => amt > 0)) {
    updateStatsBox('current-stats', currentPeriodBets);
  } else {
    document.getElementById('current-stats').innerHTML = '<div class="no-bets">No bets placed yet</div>';
  }
  
  updateBettingGraph();
}

function updateStatsBox(elementId, bets, winningNumber = null) {
  const statsBox = document.getElementById(elementId);
  if (!statsBox) return;
  
  statsBox.innerHTML = '';
  
  if (bets.green > 0) {
    const isWinner = winningNumber !== null && winningNumber !== 0 && winningNumber !== 5 && winningNumber % 2 === 1;
    statsBox.innerHTML += `<div><span>Green:</span> <span>₹${bets.green.toLocaleString()}${isWinner ? ' <i class="fas fa-trophy trophy"></i>' : ''}</span></div>`;
  }
  if (bets.red > 0) {
    const isWinner = winningNumber !== null && winningNumber !== 0 && winningNumber !== 5 && winningNumber % 2 === 0;
    statsBox.innerHTML += `<div><span>Red:</span> <span>₹${bets.red.toLocaleString()}${isWinner ? ' <i class="fas fa-trophy trophy"></i>' : ''}</span></div>`;
  }
  if (bets.violet > 0) {
    const isWinner = winningNumber !== null && (winningNumber === 0 || winningNumber === 5);
    statsBox.innerHTML += `<div><span>Violet:</span> <span>₹${bets.violet.toLocaleString()}${isWinner ? ' <i class="fas fa-trophy trophy"></i>' : ''}</span></div>`;
  }
  if (bets.big > 0) {
    const isWinner = winningNumber !== null && winningNumber >= 5;
    statsBox.innerHTML += `<div><span>Big:</span> <span>₹${bets.big.toLocaleString()}${isWinner ? ' <i class="fas fa-trophy trophy"></i>' : ''}</span></div>`;
  }
  if (bets.small > 0) {
    const isWinner = winningNumber !== null && winningNumber < 5;
    statsBox.innerHTML += `<div><span>Small:</span> <span>₹${bets.small.toLocaleString()}${isWinner ? ' <i class="fas fa-trophy trophy"></i>' : ''}</span></div>`;
  }
  if (bets.number > 0) {
    const isWinner = winningNumber !== null && parseInt(winningNumber) === parseInt(bets.number);
    statsBox.innerHTML += `<div><span>Number:</span> <span>₹${bets.number.toLocaleString()}${isWinner ? ' <i class="fas fa-trophy trophy"></i>' : ''}</span></div>`;
  }
  
  if (statsBox.innerHTML === '') {
    statsBox.innerHTML = '<div class="no-bets">No bets in this period</div>';
  }
}

function updateBettingGraph() {
  const graph = document.getElementById('betting-graph');
  if (!graph) return;
  
  graph.innerHTML = '';
  
  let betsData;
  let winningNumber = null;
  
  switch(activeChartTab) {
    case 'current':
      betsData = globalBets.current;
      break;
    case 'prev1':
      betsData = globalBets.prev1;
      if (previousPeriodsBets.length > 0) {
        winningNumber = previousPeriodsBets[0].number;
      }
      break;
    case 'prev2':
      betsData = globalBets.prev2;
      if (previousPeriodsBets.length > 1) {
        winningNumber = previousPeriodsBets[1].number;
      }
      break;
  }
  
  if (!betsData || Object.values(betsData).every(amt => amt === 0)) {
    graph.innerHTML = '<div class="no-bets-graph">No betting data available</div>';
    return;
  }
  
  const categories = [
    {name: 'Green', value: betsData.green, class: 'green', 
     isWinner: winningNumber !== null && winningNumber !== 0 && winningNumber !== 5 && winningNumber % 2 === 1},
    {name: 'Red', value: betsData.red, class: 'red', 
     isWinner: winningNumber !== null && winningNumber !== 0 && winningNumber !== 5 && winningNumber % 2 === 0},
    {name: 'Violet', value: betsData.violet, class: 'violet', 
     isWinner: winningNumber !== null && (winningNumber === 0 || winningNumber === 5)},
    {name: 'Big', value: betsData.big, class: 'big', 
     isWinner: winningNumber !== null && winningNumber >= 5},
    {name: 'Small', value: betsData.small, class: 'small', 
     isWinner: winningNumber !== null && winningNumber < 5},
    {name: 'Number', value: betsData.number, class: 'violet',
     isWinner: winningNumber !== null && parseInt(winningNumber) === parseInt(betsData.number)}
  ];
  
  const activeCategories = categories.filter(cat => cat.value > 0);
  
  if (activeCategories.length === 0) {
    graph.innerHTML = '<div class="no-bets-graph">No betting data available</div>';
    return;
  }
  
  const maxValue = Math.max(...activeCategories.map(c => c.value));
  
  activeCategories.forEach(cat => {
    const barHeight = (cat.value / maxValue) * 100;
    const bar = document.createElement('div');
    bar.className = `chart-bar ${cat.class}`;
    bar.style.height = `${barHeight}%`;
    
    bar.innerHTML = `
      <div class="chart-bar-value">₹${cat.value.toLocaleString()}${cat.isWinner ? ' <i class="fas fa-trophy trophy"></i>' : ''}</div>
      <div class="chart-bar-label">${cat.name}</div>
    `;
    
    graph.appendChild(bar);
  });
}

// Switch between chart tabs
function switchChartTab(tab) {
  activeChartTab = tab;
  document.querySelectorAll('.chart-period').forEach(el => el.classList.remove('active'));
  document.getElementById(`${tab}-period-tab`).classList.add('active');
  
  updateBettingGraph();
}

// Update page info for History
function updatePageInfo() {
  const totalPages = Math.ceil(results.length / resultsPerPage);
  const pageInfo = document.getElementById('page-info');
  if (pageInfo) {
    pageInfo.innerText = `Page ${currentPage + 1}${totalPages > 0 ? ` of ${totalPages}` : ''}`;
  }
}

// Update page info for My Bet
function updateMyBetPageInfo() {
  const totalPages = Math.ceil(userBetHistory.length / betsPerPage);
  const pageInfo = document.getElementById('mybet-page-info');
  if (pageInfo) {
    pageInfo.innerText = `Page ${myBetCurrentPage + 1}${totalPages > 0 ? ` of ${totalPages}` : ''}`;
  }
}

// Update portfolio section
function updatePortfolio() {
  document.getElementById('total-bets').textContent = gameStats.totalBets;
  document.getElementById('total-wins').textContent = `₹${gameStats.totalAmountWon.toLocaleString()}`;
  document.getElementById('biggest-win').textContent = `₹${gameStats.biggestWin.toLocaleString()}`;
  
  const winRate = gameStats.totalBets > 0 ? 
    Math.round((gameStats.totalWins / gameStats.totalBets) * 100) : 0;
  document.getElementById('win-rate').textContent = `${winRate}%`;
}

// Play sound effect
function playSound(type) {
  if (!soundEnabled) return;
  
  try {
    sounds[type].currentTime = 0;
    sounds[type].play();
  } catch (e) {
    console.log("Sound error:", e);
  }
}

// Toggle sound
function toggleSound() {
  soundEnabled = !soundEnabled;
  localStorage.setItem('soundEnabled', soundEnabled);
  updateSoundIcon();
}

// Update sound icon
function updateSoundIcon() {
  const soundToggle = document.getElementById('sound-toggle');
  if (soundToggle) {
    soundToggle.className = soundEnabled ? 'fas fa-volume-up' : 'fas fa-volume-mute';
  }
}

// Save game state
function saveGameState() {
  const state = {
    results,
    periodCounter,
    walletBalance,
    gameStats,
    globalBets,
    userBetHistory
  };
  localStorage.setItem('wingoGameState', JSON.stringify(state));
}

// Reset game
function resetGame() {
  if (confirm("Are you sure you want to reset the game? All your progress will be lost.")) {
    localStorage.removeItem('wingoGameState');
    location.reload();
  }
}

// Initialize the app
document.addEventListener('DOMContentLoaded', () => {
  initGame();
  switchSection('history');
  
  const confirmBet = document.getElementById('confirmBet');
  const cancelBet = document.getElementById('cancelBet');
  if (confirmBet) {
    confirmBet.addEventListener('click', () => {
      const betAmountInput = document.getElementById('betAmount');
      const selectedOption = document.getElementById('selectedOption')?.innerText.split(": ")[1];

      // Validate input
      const rawInput = betAmountInput?.value.trim();
      const betAmount = parseFloat(rawInput);

      // Debugging logs
      console.log('Bet Amount:', betAmount, 'Wallet Balance:', walletBalance, 'Raw Input:', rawInput);

      if (!rawInput || isNaN(betAmount) || betAmount < 1) {
        showToast("कृपया ₹1 या उससे अधिक की वैध राशि दर्ज करें।");
        return;
      }
      if (betAmount > walletBalance) {
        showToast(`अपर्याप्त बैलेंस! उपलब्ध: ₹${walletBalance.toLocaleString()}`);
        closeBattingSlide();
        return;
      }

      if (!selectedOption) {
        showToast("कृपया एक विकल्प चुनें।");
        return;
      }

      // Add to current period bets
      switch(selectedOption) {
        case 'Green':
          currentPeriodBets.green += betAmount;
          globalBets.current.green += betAmount;
          break;
        case 'Red':
          currentPeriodBets.red += betAmount;
          globalBets.current.red += betAmount;
          break;
        case 'Violet':
          currentPeriodBets.violet += betAmount;
          globalBets.current.violet += betAmount;
          break;
        case 'Big':
          currentPeriodBets.big += betAmount;
          globalBets.current.big += betAmount;
          break;
        case 'Small':
          currentPeriodBets.small += betAmount;
          globalBets.current.small += betAmount;
          break;
        default:
          currentPeriodBets.number += betAmount;
          globalBets.current.number += betAmount;
      }
      
      userBets.push({ option: selectedOption, amount: betAmount, period: periodCounter });
      
      userBetHistory.unshift({
        option: selectedOption,
        amount: betAmount,
        period: periodCounter,
        timestamp: new Date().toISOString(),
        status: 'Pending',
        winAmount: 0
      });

      walletBalance -= betAmount;
      updateWalletBalance();
      showToast(`बेट सफल! ₹${betAmount.toLocaleString()} आपके वॉलेट से कट गई है।`);
      closeBattingSlide();
      playSound('betPlaced');
      
      updateChartSection();
      updateMyBetHistory();
      updatePortfolio();
      saveGameState();
    });
  }
  if (cancelBet) cancelBet.addEventListener('click', closeBattingSlide);

  document.querySelectorAll('.quick-bet').forEach(button => {
    button.addEventListener('click', () => {
      const amount = parseInt(button.getAttribute('data-amount'));
      const betAmountInput = document.getElementById('betAmount');
      const currentValue = parseFloat(betAmountInput.value) || 0;
      betAmountInput.value = currentValue + amount;
    });
  });

  document.querySelectorAll('.number img, .heading-box').forEach(item => {
    item.addEventListener('click', (e) => {
      const selectedOption = e.target.innerText || e.target.alt;
      openBattingSlide(selectedOption);
    });
  });

  const sectionButtons = ['history-btn', 'chart-btn', 'portfolio-btn', 'mybet-btn'];
  sectionButtons.forEach(id => {
    const btn = document.getElementById(id);
    if (btn) btn.addEventListener('click', () => switchSection(id.split('-')[0]));
  });

  const previousBtn = document.getElementById('previous-btn');
  const nextBtn = document.getElementById('next-btn');
  if (previousBtn) previousBtn.addEventListener('click', showPreviousPage);
  if (nextBtn) nextBtn.addEventListener('click', showNextPage);

  const myBetPreviousBtn = document.getElementById('mybet-previous-btn');
  const myBetNextBtn = document.getElementById('mybet-next-btn');
  if (myBetPreviousBtn) myBetPreviousBtn.addEventListener('click', showPreviousMyBetPage);
  if (myBetNextBtn) myBetNextBtn.addEventListener('click', showNextMyBetPage);

  document.querySelectorAll('.chart-period').forEach(tab => {
    tab.addEventListener('click', () => {
      const tabId = tab.id.replace('-period-tab', '');
      switchChartTab(tabId);
    });
  });
  
  const soundToggle = document.getElementById('sound-toggle');
  if (soundToggle) {
    soundToggle.addEventListener('click', toggleSound);
  }
  
  let pressTimer;
  const logo = document.querySelector('.logo-container h1');
  if (logo) {
    logo.addEventListener('mousedown', () => {
      pressTimer = setTimeout(() => {
        resetGame();
      }, 3000);
    });
    
    logo.addEventListener('mouseup', () => {
      clearTimeout(pressTimer);
    });
    
    logo.addEventListener('mouseleave', () => {
      clearTimeout(pressTimer);
    });
  }
});