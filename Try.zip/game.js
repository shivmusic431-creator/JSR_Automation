let timeLeft = 30;
let results = [];
let timerInterval;
let periodCounter = 201024001;
let walletBalance = 5000;
let userBets = [];
let currentPage = 0;
const resultsPerPage = 10;

// Constants for multipliers
const MULTIPLIERS = {
    COLOR_WIN: 1.96,
    VIOLET_WIN: 4.52,
    NUMBER_WIN: 8.51,
    SPECIAL_COLOR_WIN: 1.5
};

// Start the timer
function startTimer() {
    timerInterval = setInterval(() => {
        const timerElement = document.getElementById('timer');
        if (timerElement) {
            timerElement.innerText = `00:${timeLeft < 10 ? '0' : ''}${timeLeft}`;
        }

        if (timeLeft === 3) {  // Changed from 5 to 3 seconds
            showCountdownOverlay();
            // Close betting slide if open
            closeBattingSlide();
        }

        timeLeft--;

        if (timeLeft < 0) {
            timeLeft = 30;
            generateRandomNumber();
        }
    }, 1000);
}

// Generate a random number and update results
function generateRandomNumber() {
    const number = Math.floor(Math.random() * 10);
    const colorClass = getColorClass(number);

    results.unshift({ number, colorClass, period: periodCounter });
    periodCounter++;

    updateWingoNumbers();
    updateHistory();
    updateNextPeriod();
    checkBettingResult();
}

// Get the color class for a number
function getColorClass(number) {
    if (number === 0 || number === 5) return 'violet';
    return number % 2 === 0 ? 'red' : 'green';
}

// Update Wingo numbers (latest 5 results)
function updateWingoNumbers() {
    const wingoDiv = document.getElementById('wingo-numbers');
    if (!wingoDiv) return;

    wingoDiv.innerHTML = '';
    results.slice(0, 5).forEach(result => {
        const numberCircle = document.createElement('div');
        numberCircle.classList.add('number-ball', result.colorClass);

        const numberImage = document.createElement('img');
        numberImage.src = `no${result.number}.png`;
        numberImage.alt = result.number.toString();

        numberCircle.appendChild(numberImage);
        wingoDiv.appendChild(numberCircle);
    });
}

// Update the results history with proper pagination
function updateHistory() {
    const historyDiv = document.getElementById('results-history');
    if (!historyDiv) return;

    historyDiv.innerHTML = '';
    
    const start = currentPage * resultsPerPage;
    const end = start + resultsPerPage;
    const pageResults = results.slice(start, end);

    pageResults.forEach(result => {
        const historyRow = document.createElement('div');
        historyRow.classList.add('history-row');

        const numberColorClass = result.number === 0 ? 'number-violet' :
            result.number === 5 ? 'number-green number-violet' :
            [1, 3, 7, 9].includes(result.number) ? 'number-green' : 'number-red';

        historyRow.innerHTML = `
            <div class="history-period">${result.period}</div>
            <div class="history-number ${numberColorClass}">${result.number}</div>
            <div class="history-bigsmall">${result.number >= 5 ? 'Big' : 'Small'}</div>
        `;
        historyDiv.appendChild(historyRow);
    });

    updateNavigationButtons();
}

// Update the next period number
function updateNextPeriod() {
    const nextPeriod = document.getElementById('period-number');
    if (nextPeriod) nextPeriod.innerText = periodCounter;
}

// Open the betting slide
function openBattingSlide(selectedOption) {
    const battingOverlay = document.getElementById('battingOverlay');
    const selectedOptionText = document.getElementById('selectedOption');
    if (!battingOverlay || !selectedOptionText) return;

    selectedOptionText.innerText = `Selected: ${selectedOption}`;
    battingOverlay.style.display = 'block';
    setTimeout(() => battingOverlay.classList.add('active'), 10);
}

// Close the betting slide
function closeBattingSlide() {
    const battingOverlay = document.getElementById('battingOverlay');
    if (!battingOverlay) return;

    battingOverlay.classList.remove('active');
    setTimeout(() => {
        if (battingOverlay.classList.contains('active') === false) {
            battingOverlay.style.display = 'none';
        }
    }, 300);
}

// Show toast notification
function showToast(message) {
    const toast = document.createElement('div');
    toast.classList.add('toast-notification');
    toast.innerHTML = `<div class="toast-content">${message}</div>`;
    document.body.appendChild(toast);

    setTimeout(() => toast.classList.add('show'), 10);
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

// Show custom alert
function showAlert(message, backgroundImage, isWin, winningNumber = null, winningColor = null, won = null, periodNo = null) {
    const alertBox = document.createElement('div');
    alertBox.classList.add('custom-alert');
    alertBox.style.backgroundImage = `url(${backgroundImage})`;

    alertBox.innerHTML = isWin ? `
        <div class="alert-message">
            <h1>Congratulations</h1>
            <p class="Result">Result: ${winningNumber} (${winningColor})</p>
            <p class="Won">Won: ₹${won.toFixed(2)}</p>
            <p class="period-no">Period no: ${periodNo}</p>
        </div>
    ` : `
        <div class="alert-message">
            <h1>Sorry</h1>
            <p>You didn't win this time.</p>
        </div>
    `;

    document.body.appendChild(alertBox);
    setTimeout(() => alertBox.remove(), 5000);
}

// Check betting result after each round
function checkBettingResult() {
    if (userBets.length === 0) return;

    const latestResult = results[0];
    let totalWinAmount = 0;
    let hasWon = false;

    userBets.forEach(bet => {
        let winAmount = 0;
        const isBig = bet.option === "Big" && latestResult.number >= 5;
        const isSmall = bet.option === "Small" && latestResult.number < 5;
        const isRed = bet.option === "Red" && latestResult.colorClass === "red";
        const isGreen = bet.option === "Green" && latestResult.colorClass === "green";
        const isViolet = bet.option === "Violet" && latestResult.colorClass === "violet";
        const isNumber = parseInt(bet.option) === latestResult.number;

        if (isBig || isSmall || (isRed && latestResult.number !== 5) || (isGreen && latestResult.number !== 0)) {
            winAmount = bet.amount * MULTIPLIERS.COLOR_WIN;
        } else if ((isRed && latestResult.number === 0) || (isGreen && latestResult.number === 5)) {
            winAmount = bet.amount * MULTIPLIERS.SPECIAL_COLOR_WIN;
        } else if (isViolet) {
            winAmount = bet.amount * MULTIPLIERS.VIOLET_WIN;
        } else if (isNumber) {
            winAmount = bet.amount * MULTIPLIERS.NUMBER_WIN;
        }

        if (winAmount > 0) {
            walletBalance += winAmount;
            totalWinAmount += winAmount;
            hasWon = true;
        }
    });

    if (hasWon) {
        showAlert(`You Won\n₹${totalWinAmount.toFixed(2)}`, 'win.png', true, latestResult.number, latestResult.colorClass, totalWinAmount, latestResult.period);
    } else {
        showAlert("Didn't Win", 'loss.png', false);
    }

    userBets = [];
    const walletBalanceBox = document.getElementById('walletBalanceBox');
    if (walletBalanceBox) walletBalanceBox.innerText = ` ₹${walletBalance}`;
}

// Update navigation buttons state
function updateNavigationButtons() {
    const previousBtn = document.getElementById('previous-btn');
    const nextBtn = document.getElementById('next-btn');
    if (!previousBtn || !nextBtn) return;

    previousBtn.disabled = currentPage === 0;
    nextBtn.disabled = (currentPage + 1) * resultsPerPage >= results.length;
}

// Show previous/next page
function showPreviousPage() {
    if (currentPage > 0) {
        currentPage--;
        updateHistory();
    }
}

function showNextPage() {
    if ((currentPage + 1) * resultsPerPage < results.length) {
        currentPage++;
        updateHistory();
    }
}

// Show countdown overlay (changed to 3 seconds)
function showCountdownOverlay() {
    const gameBox = document.querySelector('.game-box');
    if (!gameBox) return;

    const countdownOverlay = document.createElement('div');
    countdownOverlay.classList.add('countdown-overlay');
    countdownOverlay.innerHTML = `<div class="countdown-timer">3</div>`;
    gameBox.appendChild(countdownOverlay);

    let countdown = 3;  // Changed from 5 to 3 seconds
    const countdownInterval = setInterval(() => {
        countdown--;
        countdownOverlay.querySelector('.countdown-timer').innerText = countdown;
        if (countdown <= 0) {
            clearInterval(countdownInterval);
            countdownOverlay.remove();
        }
    }, 1000);
}

// Switch between sections
function switchSection(section) {
    const sections = ['results-history', 'chart-section', 'portfolio-section', 'history-navigation'];
    sections.forEach(id => {
        const element = document.getElementById(id);
        if (element) element.style.display = 'none';
    });

    if (section === 'history') {
        const history = document.getElementById('results-history');
        const navigation = document.getElementById('history-navigation');
        if (history) history.style.display = 'block';
        if (navigation) navigation.style.display = 'block';
    } else if (section === 'chart') {
        const chart = document.getElementById('chart-section');
        if (chart) chart.style.display = 'block';
    } else if (section === 'portfolio') {
        const portfolio = document.getElementById('portfolio-section');
        if (portfolio) portfolio.style.display = 'block';
    }

    document.querySelectorAll('.section-btn').forEach(btn => btn.classList.remove('active'));
    const activeBtn = document.getElementById(`${section}-btn`);
    if (activeBtn) activeBtn.classList.add('active');
}

// Initialize the app
document.addEventListener('DOMContentLoaded', () => {
    // Initial setup
    switchSection('history');
    startTimer();

    // Event listeners for betting
    const confirmBet = document.getElementById('confirmBet');
    const cancelBet = document.getElementById('cancelBet');
    if (confirmBet) {
        confirmBet.addEventListener('click', () => {
            const betAmount = parseInt(document.getElementById('betAmount')?.value, 10);
            const selectedOption = document.getElementById('selectedOption')?.innerText.split(": ")[1];

            if (isNaN(betAmount) || betAmount <= 0) {
                showToast("कृपया वैध राशि दर्ज करें।");
                return;
            }
            if (betAmount > walletBalance) {
                showToast("अपर्याप्त बैलेंस!");
                closeBattingSlide();
            } else {
                userBets.push({ option: selectedOption, amount: betAmount });
                walletBalance -= betAmount;
                const walletBalanceBox = document.getElementById('walletBalanceBox');
                if (walletBalanceBox) walletBalanceBox.innerText = ` ₹${walletBalance}`;
                showToast(`बेट सफल! ₹${betAmount} आपके वॉलेट से कट गई है।`);
                closeBattingSlide();
            }
        });
    }
    if (cancelBet) cancelBet.addEventListener('click', closeBattingSlide);

    // Event listeners for number/option selection
    document.querySelectorAll('.number-ball, .heading-box').forEach(item => {
        item.addEventListener('click', (e) => {
            const selectedOption = e.target.innerText || e.target.alt;
            openBattingSlide(selectedOption);
        });
    });

    // Event listeners for section buttons
    const sectionButtons = ['history-btn', 'chart-btn', 'portfolio-btn'];
    sectionButtons.forEach(id => {
        const btn = document.getElementById(id);
        if (btn) btn.addEventListener('click', () => switchSection(id.split('-')[0]));
    });

    // Event listeners for navigation
    const previousBtn = document.getElementById('previous-btn');
    const nextBtn = document.getElementById('next-btn');
    if (previousBtn) previousBtn.addEventListener('click', showPreviousPage);
    if (nextBtn) nextBtn.addEventListener('click', showNextPage);
});